# DSP Project Report Source

Editable LaTeX source for **License Plate Recognition Processing Using DSP Features**, prepared in a separate directory from the Android and Python application.

## Build

Open this directory and compile `report.tex` with MiKTeX:

```powershell
latexmk -pdf -interaction=nonstopmode -halt-on-error -file-line-error report.tex
```

The source uses the institutional template's book layout and front matter. Real processing-stage images from the ALPR project's saved investigation output are copied into `assets/`; selected code excerpts are in `listings/`. The complete application remains at `C:\vidya collage\projects\dsptest`.

The report intentionally does not claim a measured overall recognition accuracy or performance benchmark. The saved JSON and images document a qualitative example only.
