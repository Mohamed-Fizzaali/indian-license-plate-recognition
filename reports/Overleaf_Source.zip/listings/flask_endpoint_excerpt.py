﻿@app.route("/recognize", methods=["POST"])
def recognize():
    if "image" not in request.files:
        return jsonify({"error": "No image uploaded"}), 400

    file = request.files["image"]
    image_bytes = file.read()

    image_array = np.frombuffer(image_bytes, dtype=np.uint8)
    image = cv2.imdecode(image_array, cv2.IMREAD_COLOR)

    if image is None:
        return jsonify({"error": "Invalid image"}), 400

    result = recognize_for_app(image)

    return jsonify({
        "plate_number": result.plate_number,
        "confidence": result.confidence,
        "valid_indian_format": result.valid_indian_format,
        "status": result.processing_status,
        "error": result.error,
    })


