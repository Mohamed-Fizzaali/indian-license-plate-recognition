﻿    return float(
        0.27 * aspect_score
        + 0.27 * brightness_score
        + 0.16 * contrast_score
        + 0.18 * char_score
        + 0.07 * rect_score
        + 0.05 * edge_score
    )
