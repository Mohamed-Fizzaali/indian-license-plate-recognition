﻿def recognize_crop(crop: np.ndarray, include_diagnostics: bool = False) -> OCRResult:
    """Recognize a plate crop with RapidOCR, Tesseract, or local templates."""
    rectified = rectify_plate(crop)
    variants = preprocess_plate(rectified)
    rapid = _rapidocr_read(variants)
    if rapid and rapid[0] >= 0.75 and INDIA_PATTERN.fullmatch(rapid[1]):
        processed = variants.get("otsu", variants.get("gray"))
        diagnostics = (
            {
                "selection_path": "rapidocr_format_fast_path",
                "ocr_method_candidates": [
                    {"method": rapid[2], "text": rapid[1], "confidence": rapid[0]}
                ],
                "template_evidence": {"evaluated": False, "reason": "RapidOCR fast path"},
            }
            if include_diagnostics
            else None
        )
        return OCRResult(rapid[1], rapid[0], rapid[2], processed, variants, diagnostics)
    if rapid and rapid[0] >= 0.50 and not shutil.which("tesseract"):
        processed = variants.get("otsu", variants.get("gray"))
        diagnostics = (
            {
                "selection_path": "rapidocr_no_tesseract_fast_path",
                "ocr_method_candidates": [
                    {"method": rapid[2], "text": rapid[1], "confidence": rapid[0]}
                ],
                "template_evidence": {"evaluated": False, "reason": "RapidOCR fast path"},
            }
            if include_diagnostics
            else None
        )
        return OCRResult(rapid[1], rapid[0], rapid[2], processed, variants, diagnostics)
    tess = _tesseract_read(variants)
    template_diagnostics: dict[str, object] | None = {} if include_diagnostics else None
    fallback_text, fallback_conf, fallback_method = _template_read(variants, template_diagnostics)
    choices: list[tuple[float, str, str]] = []
    if rapid:
        choices.append(rapid)
    if tess and tess[0]:
        choices.append((tess[1], tess[0], tess[2]))
    if fallback_text:
        choices.append((fallback_conf, fallback_text, fallback_method))
    if choices:
        # Prefer syntactically plausible reads when model confidences are
        # close, but keep OCR confidence as the dominant signal.
        choices.sort(key=lambda item: item[0] + (0.12 if INDIA_PATTERN.fullmatch(item[1]) else 0.0), reverse=True)
        confidence, text, method = choices[0]
        confidence = min(1.0, confidence)
    else:
        confidence, text, method = 0.0, "", "no-ocr-result"
