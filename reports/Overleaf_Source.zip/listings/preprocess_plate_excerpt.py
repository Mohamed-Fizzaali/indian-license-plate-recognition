﻿def preprocess_plate(crop: np.ndarray) -> dict[str, np.ndarray]:
    """Normalize contrast, upscale, and produce threshold variants for OCR."""
    if crop.ndim == 3:
        gray = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)
    else:
        gray = crop.copy()
    if gray.size == 0:
        return {"gray": gray}
    # A light unsharp mask restores edges softened by a small source image.
    gray = cv2.createCLAHE(clipLimit=2.5, tileGridSize=(4, 4)).apply(gray)
    smooth = cv2.bilateralFilter(gray, 5, 28, 28)
    sharpened = cv2.addWeighted(smooth, 1.7, cv2.GaussianBlur(smooth, (0, 0), 1.1), -0.7, 0)
    target_h = 112 if gray.shape[0] < 32 else 96
    scale = max(2.0, min(8.0, target_h / max(gray.shape[0], 1)))
    size = (max(1, int(gray.shape[1] * scale)), max(1, int(gray.shape[0] * scale)))
    enlarged = cv2.resize(sharpened, size, interpolation=cv2.INTER_CUBIC)
    enlarged = cv2.copyMakeBorder(enlarged, 8, 8, 10, 10, cv2.BORDER_REPLICATE)
    _, otsu = cv2.threshold(enlarged, 0, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)
    adaptive = cv2.adaptiveThreshold(
        enlarged, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 31, 9
    )
    # Inverse masks are useful for component segmentation; standard black text
    # on white remains the preferred input to Tesseract.
    return {
        "gray": enlarged,
        "otsu": otsu,
        "adaptive": adaptive,
        "otsu_inverse": cv2.bitwise_not(otsu),
        "adaptive_inverse": cv2.bitwise_not(adaptive),
    }
