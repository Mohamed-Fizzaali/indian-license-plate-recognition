﻿    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    clahe = cv2.createCLAHE(clipLimit=2.2, tileGridSize=(8, 8)).apply(gray)
    filtered = cv2.bilateralFilter(clahe, 7, 55, 55)

    grad_x = cv2.Sobel(filtered, cv2.CV_32F, 1, 0, ksize=3)
    grad_x = cv2.convertScaleAbs(grad_x)
    _, grad_mask = cv2.threshold(grad_x, 0, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)
    horizontal_kernel = cv2.getStructuringElement(
        cv2.MORPH_RECT, (max(9, int(width * 0.045)) | 1, max(3, int(height * 0.012)) | 1)
    )
    gradient_map = cv2.morphologyEx(grad_mask, cv2.MORPH_CLOSE, horizontal_kernel, iterations=2)
    gradient_map = cv2.morphologyEx(
        gradient_map, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
    )

    edges = cv2.Canny(filtered, 55, 165)
    edge_map = cv2.morphologyEx(edges, cv2.MORPH_CLOSE, horizontal_kernel, iterations=2)
    edge_map = cv2.dilate(edge_map, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3)), iterations=1)

    adaptive = cv2.adaptiveThreshold(
        filtered, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY_INV, 21, 7
    )
    adaptive_map = cv2.morphologyEx(adaptive, cv2.MORPH_CLOSE, horizontal_kernel, iterations=1)
